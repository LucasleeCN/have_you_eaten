package com.example.have_you_eaten.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.have_you_eaten.R;


public class MenuActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu);
        EditText editText= findViewById(R.id.edittext_input);
        Button btSearch = (Button)findViewById(R.id.search_button);
        Button btOrder = (Button)findViewById(R.id.Order);
        Button btPerson = (Button)findViewById(R.id.Settings);
        btOrder.setOnClickListener(this);
        btPerson.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch(view.getId()){
            case R.id.search_button:
                break;
            case R.id.Order:
                Intent intentOrder=new Intent(MenuActivity.this,OrderActivity.class);
                startActivity(intentOrder);
                break;
            case R.id.Settings:
                Intent userOrder=new Intent(MenuActivity.this, MainActivity.class);
                startActivity(userOrder);
                break;


                //ListView listview=findViewById(R.id.shops);
                //listview.setAdapter(adapter);
                //for (int i = 0; i < songlist.length; i++) {
                  //  data[i] = songlist[i].getName();
                }
        }
    }

//    public void setColor(){
//        SearchView searchView=(SearchView)findViewById(R.id.search1);
//        Button btSearch2 = (Button)findViewById(R.id.search2);
//
//    }

