package com.example.have_you_eaten.adapter;

import android.widget.TextView;

/**
 * viewHolder类，封装Textview类
 */
public class ShopViewHolder {
    TextView name ;
    TextView address;
}
