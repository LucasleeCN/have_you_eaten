package com.example.have_you_eaten.adapter;

import android.widget.TextView;

/**
 * 实现ViewHolder的属性
 */
public class OrderViewHolder {
    /**
     * 以下依次对应businesscenter.xml下的title、phone、account、iden_number，用于在orderAdapter中使用
     */
    TextView producer;
    TextView commodity;

}
