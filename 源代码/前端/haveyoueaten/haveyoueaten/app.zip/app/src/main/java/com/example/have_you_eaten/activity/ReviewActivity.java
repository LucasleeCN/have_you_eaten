package com.example.have_you_eaten.activity;

import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.example.have_you_eaten.R;

class ReviewActivity extends AppCompatActivity implements View.OnClickListener {


    //初始化
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu);
    }
    
    @Override
    public void onClick(View v) {
        
    }
}
