package com.example.have_you_eaten.bean;

/**
 * 商品评价类
 */
public class Review {
    private String user_name;
    private String note;

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }
}
