package com.example.have_you_eaten.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import com.example.have_you_eaten.R;


public class BusinessActivity extends AppCompatActivity implements View.OnClickListener {
    Button exit ;
    public void init(){
        exit=findViewById(R.id.exit);
        exit.setOnClickListener(this);
    }
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.businesscenter);
        init();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.exit:
                /**
                 * TODO 跳转至登录界面
                 */
                break;
        }
    }
}
