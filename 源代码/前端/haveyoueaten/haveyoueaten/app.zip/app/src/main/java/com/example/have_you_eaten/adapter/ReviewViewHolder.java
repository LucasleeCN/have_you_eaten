package com.example.have_you_eaten.adapter;


import android.widget.TextView;

/**
 * 实现ViewHolder的属性
 */
public class ReviewViewHolder {
    /**
     * 以下依次对应revire_item.xml下的username和note
     */
    TextView name;
    TextView note;

}
